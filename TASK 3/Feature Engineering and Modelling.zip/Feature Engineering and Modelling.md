# Feature Engineering and Modelling


```python
1. Import Packages
2. Load Data
3. Feature Engineering
4. Build Predictive Models
```


      Cell In[6], line 1
        1. Import Packages
           ^
    SyntaxError: invalid syntax
    

1. IMPORT PACKAGES

```python
!pip3 install imblearn
```

    Requirement already satisfied: imblearn in c:\users\asus\anaconda3\lib\site-packages (0.0)
    Requirement already satisfied: imbalanced-learn in c:\users\asus\anaconda3\lib\site-packages (from imblearn) (0.10.1)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\asus\anaconda3\lib\site-packages (from imbalanced-learn->imblearn) (1.24.3)
    Requirement already satisfied: scipy>=1.3.2 in c:\users\asus\anaconda3\lib\site-packages (from imbalanced-learn->imblearn) (1.11.1)
    Requirement already satisfied: scikit-learn>=1.0.2 in c:\users\asus\anaconda3\lib\site-packages (from imbalanced-learn->imblearn) (1.3.0)
    Requirement already satisfied: joblib>=1.1.1 in c:\users\asus\anaconda3\lib\site-packages (from imbalanced-learn->imblearn) (1.2.0)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\users\asus\anaconda3\lib\site-packages (from imbalanced-learn->imblearn) (2.2.0)
    


```python
#import the necessary libraries 
import pandas as pd #data processing
import numpy as np # linear algebra
import matplotlib.pyplot as plt #data plot
%matplotlib inline 
import seaborn as sns #data plot
import warnings
warnings.filterwarnings("ignore") #ignore warning
```
2. LOAD DATA

```python
df= pd.read_csv('./clean_data_after_eda.csv')
df["date_activ"] = pd.to_datetime(df["date_activ"], format='%Y-%m-%d')
df["date_end"] = pd.to_datetime(df["date_end"], format='%Y-%m-%d')
df["date_modif_prod"] = pd.to_datetime(df["date_modif_prod"], format='%Y-%m-%d')
df["date_renewal"] = pd.to_datetime(df["date_renewal"], format='%Y-%m-%d')
```


```python
df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>channel_sales</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>date_activ</th>
      <th>date_end</th>
      <th>date_modif_prod</th>
      <th>date_renewal</th>
      <th>forecast_cons_12m</th>
      <th>...</th>
      <th>var_6m_price_off_peak_var</th>
      <th>var_6m_price_peak_var</th>
      <th>var_6m_price_mid_peak_var</th>
      <th>var_6m_price_off_peak_fix</th>
      <th>var_6m_price_peak_fix</th>
      <th>var_6m_price_mid_peak_fix</th>
      <th>var_6m_price_off_peak</th>
      <th>var_6m_price_peak</th>
      <th>var_6m_price_mid_peak</th>
      <th>churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>2013-06-15</td>
      <td>2016-06-15</td>
      <td>2015-11-01</td>
      <td>2015-06-23</td>
      <td>0.00</td>
      <td>...</td>
      <td>0.000131</td>
      <td>4.100838e-05</td>
      <td>0.000908</td>
      <td>2.086294</td>
      <td>99.530517</td>
      <td>44.235794</td>
      <td>2.086425</td>
      <td>9.953056e+01</td>
      <td>44.236702</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>MISSING</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>2009-08-21</td>
      <td>2016-08-30</td>
      <td>2009-08-21</td>
      <td>2015-08-31</td>
      <td>189.95</td>
      <td>...</td>
      <td>0.000003</td>
      <td>1.217891e-03</td>
      <td>0.000000</td>
      <td>0.009482</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.009485</td>
      <td>1.217891e-03</td>
      <td>0.000000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>2010-04-16</td>
      <td>2016-04-16</td>
      <td>2010-04-16</td>
      <td>2015-04-17</td>
      <td>47.96</td>
      <td>...</td>
      <td>0.000004</td>
      <td>9.450150e-08</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000004</td>
      <td>9.450150e-08</td>
      <td>0.000000</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 44 columns</p>
</div>


This data consists of PowerCo's churn information which mean customer will switch to another provider or not. Scroll to the right if necessary, and note that the final column in the dataset (Churn) contains the value 0 for customer who doesn't churn, and 1 for patients who churns. This is the label that we will train our model to predict; other columns are the features we will use to predict the Churn label.

As usual, I'll train a binary classifier to predict whether or not a customer should be churn based on some historical data. But according to task requirements, a Random Forest classifier will used to predict customer churn and evaluate the performance of the model with suitable evaluation metrics.

For tree-based models, there is no need to perform data scaling, unlike other machine learning models. And dont need to apply one-hot encoding to processing categorical variables, just use label-encoding to convert categorical variables to numeric variables.

```python
df.shape #check the shape of the dataset
```




    (14606, 44)




```python
df.dtypes
```




    id                                        object
    channel_sales                             object
    cons_12m                                   int64
    cons_gas_12m                               int64
    cons_last_month                            int64
    date_activ                        datetime64[ns]
    date_end                          datetime64[ns]
    date_modif_prod                   datetime64[ns]
    date_renewal                      datetime64[ns]
    forecast_cons_12m                        float64
    forecast_cons_year                         int64
    forecast_discount_energy                 float64
    forecast_meter_rent_12m                  float64
    forecast_price_energy_off_peak           float64
    forecast_price_energy_peak               float64
    forecast_price_pow_off_peak              float64
    has_gas                                   object
    imp_cons                                 float64
    margin_gross_pow_ele                     float64
    margin_net_pow_ele                       float64
    nb_prod_act                                int64
    net_margin                               float64
    num_years_antig                            int64
    origin_up                                 object
    pow_max                                  float64
    var_year_price_off_peak_var              float64
    var_year_price_peak_var                  float64
    var_year_price_mid_peak_var              float64
    var_year_price_off_peak_fix              float64
    var_year_price_peak_fix                  float64
    var_year_price_mid_peak_fix              float64
    var_year_price_off_peak                  float64
    var_year_price_peak                      float64
    var_year_price_mid_peak                  float64
    var_6m_price_off_peak_var                float64
    var_6m_price_peak_var                    float64
    var_6m_price_mid_peak_var                float64
    var_6m_price_off_peak_fix                float64
    var_6m_price_peak_fix                    float64
    var_6m_price_mid_peak_fix                float64
    var_6m_price_off_peak                    float64
    var_6m_price_peak                        float64
    var_6m_price_mid_peak                    float64
    churn                                      int64
    dtype: object


3. Features EngineeringDifference between off-peak prices in December and preceding January
Below is the code created by your colleague to calculate the feature described above. Use this code to re-create this feature and then think about ways to build on this feature to create features with a higher predictive power.

```python
price_df = pd.read_csv('price_data.csv')
price_df["price_date"] = pd.to_datetime(price_df["price_date"], format='%Y-%m-%d')
price_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>price_date</th>
      <th>price_off_peak_var</th>
      <th>price_peak_var</th>
      <th>price_mid_peak_var</th>
      <th>price_off_peak_fix</th>
      <th>price_peak_fix</th>
      <th>price_mid_peak_fix</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>038af19179925da21a25619c5a24b745</td>
      <td>2015-01-01</td>
      <td>0.151367</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>44.266931</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>038af19179925da21a25619c5a24b745</td>
      <td>2015-02-01</td>
      <td>0.151367</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>44.266931</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>038af19179925da21a25619c5a24b745</td>
      <td>2015-03-01</td>
      <td>0.151367</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>44.266931</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>038af19179925da21a25619c5a24b745</td>
      <td>2015-04-01</td>
      <td>0.149626</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>44.266931</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>038af19179925da21a25619c5a24b745</td>
      <td>2015-05-01</td>
      <td>0.149626</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>44.266931</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Group off-peak prices by companies and month
monthly_price_by_id = price_df.groupby(['id', 'price_date']).agg({'price_off_peak_var': 'mean', 'price_off_peak_fix': 'mean'}).reset_index()

# Get january and december prices
jan_prices = monthly_price_by_id.groupby('id').first().reset_index()
dec_prices = monthly_price_by_id.groupby('id').last().reset_index()

# Calculate the difference
diff = pd.merge(dec_prices.rename(columns={'price_off_peak_var': 'dec_1', 'price_off_peak_fix': 'dec_2'}), jan_prices.drop(columns='price_date'), on='id')
diff['offpeak_diff_dec_january_energy'] = diff['dec_1'] - diff['price_off_peak_var']
diff['offpeak_diff_dec_january_power'] = diff['dec_2'] - diff['price_off_peak_fix']
diff = diff[['id', 'offpeak_diff_dec_january_energy','offpeak_diff_dec_january_power']]
diff.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>offpeak_diff_dec_january_energy</th>
      <th>offpeak_diff_dec_january_power</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>-0.006192</td>
      <td>0.162916</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0004351ebdd665e6ee664792efc4fd13</td>
      <td>-0.004104</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0010bcc39e42b3c2131ed2ce55246e3c</td>
      <td>0.050443</td>
      <td>1.500000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0010ee3855fdea87602a5b7aba8e42de</td>
      <td>-0.010018</td>
      <td>0.162916</td>
    </tr>
    <tr>
      <th>4</th>
      <td>00114d74e963e47177db89bc70108537</td>
      <td>-0.003994</td>
      <td>-0.000001</td>
    </tr>
  </tbody>
</table>
</div>




```python
monthly_price_by_id.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>price_date</th>
      <th>price_off_peak_var</th>
      <th>price_off_peak_fix</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-01-01</td>
      <td>0.126098</td>
      <td>40.565969</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-02-01</td>
      <td>0.126098</td>
      <td>40.565969</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-03-01</td>
      <td>0.128067</td>
      <td>40.728885</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-04-01</td>
      <td>0.128067</td>
      <td>40.728885</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-05-01</td>
      <td>0.128067</td>
      <td>40.728885</td>
    </tr>
  </tbody>
</table>
</div>




```python
jan_prices.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>price_date</th>
      <th>price_off_peak_var</th>
      <th>price_off_peak_fix</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0002203ffbb812588b632b9e628cc38d</td>
      <td>2015-01-01</td>
      <td>0.126098</td>
      <td>40.565969</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0004351ebdd665e6ee664792efc4fd13</td>
      <td>2015-01-01</td>
      <td>0.148047</td>
      <td>44.266931</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0010bcc39e42b3c2131ed2ce55246e3c</td>
      <td>2015-01-01</td>
      <td>0.150837</td>
      <td>44.444710</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0010ee3855fdea87602a5b7aba8e42de</td>
      <td>2015-01-01</td>
      <td>0.123086</td>
      <td>40.565969</td>
    </tr>
    <tr>
      <th>4</th>
      <td>00114d74e963e47177db89bc70108537</td>
      <td>2015-01-01</td>
      <td>0.149434</td>
      <td>44.266931</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = pd.merge(df, diff, on='id')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>channel_sales</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>date_activ</th>
      <th>date_end</th>
      <th>date_modif_prod</th>
      <th>date_renewal</th>
      <th>forecast_cons_12m</th>
      <th>...</th>
      <th>var_6m_price_mid_peak_var</th>
      <th>var_6m_price_off_peak_fix</th>
      <th>var_6m_price_peak_fix</th>
      <th>var_6m_price_mid_peak_fix</th>
      <th>var_6m_price_off_peak</th>
      <th>var_6m_price_peak</th>
      <th>var_6m_price_mid_peak</th>
      <th>churn</th>
      <th>offpeak_diff_dec_january_energy</th>
      <th>offpeak_diff_dec_january_power</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>2013-06-15</td>
      <td>2016-06-15</td>
      <td>2015-11-01</td>
      <td>2015-06-23</td>
      <td>0.00</td>
      <td>...</td>
      <td>9.084737e-04</td>
      <td>2.086294</td>
      <td>99.530517</td>
      <td>44.235794</td>
      <td>2.086425</td>
      <td>9.953056e+01</td>
      <td>4.423670e+01</td>
      <td>1</td>
      <td>0.020057</td>
      <td>3.700961</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>MISSING</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>2009-08-21</td>
      <td>2016-08-30</td>
      <td>2009-08-21</td>
      <td>2015-08-31</td>
      <td>189.95</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.009482</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.009485</td>
      <td>1.217891e-03</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.003767</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>2010-04-16</td>
      <td>2016-04-16</td>
      <td>2010-04-16</td>
      <td>2015-04-17</td>
      <td>47.96</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000004</td>
      <td>9.450150e-08</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.004670</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bba03439a292a1e166f80264c16191cb</td>
      <td>lmkebamcaaclubfxadlmueccxoimlema</td>
      <td>1584</td>
      <td>0</td>
      <td>0</td>
      <td>2010-03-30</td>
      <td>2016-03-30</td>
      <td>2010-03-30</td>
      <td>2015-03-31</td>
      <td>240.04</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000003</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.004547</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>4</th>
      <td>149d57cf92fc41cf94415803a877cb4b</td>
      <td>MISSING</td>
      <td>4425</td>
      <td>0</td>
      <td>526</td>
      <td>2010-01-13</td>
      <td>2016-03-07</td>
      <td>2010-01-13</td>
      <td>2015-03-09</td>
      <td>445.75</td>
      <td>...</td>
      <td>4.860000e-10</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000011</td>
      <td>2.896760e-06</td>
      <td>4.860000e-10</td>
      <td>0</td>
      <td>-0.006192</td>
      <td>0.162916</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 46 columns</p>
</div>


In the dataset, we have some datetime features:

date_activ = date of activation of the contract
date_end = registered date of the end of the contract
date_modif_prod = date of the last modification of the product
date_renewal = date of the next contract renewal From these features, we can create new columns called:
tenure: the time customer uses service of PowerCo
months_activ = Number of months active until reference date (Jan 2016)
months_to_end = Number of months of the contract left until reference date (Jan 2016)
months_modif_prod = Number of months since last modification until reference date (Jan 2016)
months_renewal = Number of months since last renewal until reference date (Jan 2016)

```python
# We no longer need the datetime columns so we can drop them

remove = ['date_activ', 'date_end', 'date_modif_prod', 'date_renewal']

df = df.drop(columns=remove)
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>channel_sales</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>forecast_cons_12m</th>
      <th>forecast_cons_year</th>
      <th>forecast_discount_energy</th>
      <th>forecast_meter_rent_12m</th>
      <th>forecast_price_energy_off_peak</th>
      <th>...</th>
      <th>var_6m_price_mid_peak_var</th>
      <th>var_6m_price_off_peak_fix</th>
      <th>var_6m_price_peak_fix</th>
      <th>var_6m_price_mid_peak_fix</th>
      <th>var_6m_price_off_peak</th>
      <th>var_6m_price_peak</th>
      <th>var_6m_price_mid_peak</th>
      <th>churn</th>
      <th>offpeak_diff_dec_january_energy</th>
      <th>offpeak_diff_dec_january_power</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>0.00</td>
      <td>0</td>
      <td>0.0</td>
      <td>1.78</td>
      <td>0.114481</td>
      <td>...</td>
      <td>9.084737e-04</td>
      <td>2.086294</td>
      <td>99.530517</td>
      <td>44.235794</td>
      <td>2.086425</td>
      <td>9.953056e+01</td>
      <td>4.423670e+01</td>
      <td>1</td>
      <td>0.020057</td>
      <td>3.700961</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>MISSING</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>189.95</td>
      <td>0</td>
      <td>0.0</td>
      <td>16.27</td>
      <td>0.145711</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.009482</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.009485</td>
      <td>1.217891e-03</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.003767</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>foosdfpfkusacimwkcsosbicdxkicaua</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>47.96</td>
      <td>0</td>
      <td>0.0</td>
      <td>38.72</td>
      <td>0.165794</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000004</td>
      <td>9.450150e-08</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.004670</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bba03439a292a1e166f80264c16191cb</td>
      <td>lmkebamcaaclubfxadlmueccxoimlema</td>
      <td>1584</td>
      <td>0</td>
      <td>0</td>
      <td>240.04</td>
      <td>0</td>
      <td>0.0</td>
      <td>19.83</td>
      <td>0.146694</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000003</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0</td>
      <td>-0.004547</td>
      <td>0.177779</td>
    </tr>
    <tr>
      <th>4</th>
      <td>149d57cf92fc41cf94415803a877cb4b</td>
      <td>MISSING</td>
      <td>4425</td>
      <td>0</td>
      <td>526</td>
      <td>445.75</td>
      <td>526</td>
      <td>0.0</td>
      <td>131.73</td>
      <td>0.116900</td>
      <td>...</td>
      <td>4.860000e-10</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000011</td>
      <td>2.896760e-06</td>
      <td>4.860000e-10</td>
      <td>0</td>
      <td>-0.006192</td>
      <td>0.162916</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 42 columns</p>
</div>




```python
Transform Categorical Data
```


      Cell In[66], line 1
        Transform Categorical Data
                  ^
    SyntaxError: invalid syntax
    



```python
We have 3 categorical variables including: has_gas, channel_sales, origin_up.
```


      Cell In[67], line 1
        We have 3 categorical variables including: has_gas, channel_sales, origin_up.
           ^
    SyntaxError: invalid syntax
    



```python
#For the column has_gas, replace t for 1 and f for 0
df['has_gas']=df['has_gas'].replace(['t','f'],[1,0])
```


```python
Let's check values of the two others.
```


      Cell In[69], line 1
        Let's check values of the two others.
           ^
    SyntaxError: unterminated string literal (detected at line 1)
    



```python
df['channel_sales'].value_counts()
```




    channel_sales
    foosdfpfkusacimwkcsosbicdxkicaua    6754
    MISSING                             3725
    lmkebamcaaclubfxadlmueccxoimlema    1843
    usilxuppasemubllopkaafesmlibmsdf    1375
    ewpakwlliwisiwduibdlfmalxowmwpci     893
    sddiedcslfslkckwlfkdpoeeailfpeds      11
    epumfxlbckeskwekxbiuasklxalciiuu       3
    fixdbufsefwooaasfcxdxadsiekoceaa       2
    Name: count, dtype: int64




```python
df['origin_up'].value_counts()
```




    origin_up
    lxidpiddsbxsbosboudacockeimpuepw    7097
    kamkkxfxxuwbdslkwifmmcsiusiuosws    4294
    ldkssxwpmemidmecebumciepifcamkci    3148
    MISSING                               64
    usapbepcfoloekilkwsdiboslwaxobdp       2
    ewxeelcelemmiwuafmddpobolfuxioce       1
    Name: count, dtype: int64




```python
#One hot encoding using get_dummies()
df = pd.get_dummies(df, columns = ['channel_sales', 'origin_up'])
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>forecast_cons_12m</th>
      <th>forecast_cons_year</th>
      <th>forecast_discount_energy</th>
      <th>forecast_meter_rent_12m</th>
      <th>forecast_price_energy_off_peak</th>
      <th>forecast_price_energy_peak</th>
      <th>...</th>
      <th>channel_sales_foosdfpfkusacimwkcsosbicdxkicaua</th>
      <th>channel_sales_lmkebamcaaclubfxadlmueccxoimlema</th>
      <th>channel_sales_sddiedcslfslkckwlfkdpoeeailfpeds</th>
      <th>channel_sales_usilxuppasemubllopkaafesmlibmsdf</th>
      <th>origin_up_MISSING</th>
      <th>origin_up_ewxeelcelemmiwuafmddpobolfuxioce</th>
      <th>origin_up_kamkkxfxxuwbdslkwifmmcsiusiuosws</th>
      <th>origin_up_ldkssxwpmemidmecebumciepifcamkci</th>
      <th>origin_up_lxidpiddsbxsbosboudacockeimpuepw</th>
      <th>origin_up_usapbepcfoloekilkwsdiboslwaxobdp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>0.00</td>
      <td>0</td>
      <td>0.0</td>
      <td>1.78</td>
      <td>0.114481</td>
      <td>0.098142</td>
      <td>...</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>189.95</td>
      <td>0</td>
      <td>0.0</td>
      <td>16.27</td>
      <td>0.145711</td>
      <td>0.000000</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>47.96</td>
      <td>0</td>
      <td>0.0</td>
      <td>38.72</td>
      <td>0.165794</td>
      <td>0.087899</td>
      <td>...</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bba03439a292a1e166f80264c16191cb</td>
      <td>1584</td>
      <td>0</td>
      <td>0</td>
      <td>240.04</td>
      <td>0</td>
      <td>0.0</td>
      <td>19.83</td>
      <td>0.146694</td>
      <td>0.000000</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>149d57cf92fc41cf94415803a877cb4b</td>
      <td>4425</td>
      <td>0</td>
      <td>526</td>
      <td>445.75</td>
      <td>526</td>
      <td>0.0</td>
      <td>131.73</td>
      <td>0.116900</td>
      <td>0.100015</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 54 columns</p>
</div>




```python
#remove values with very little occurences
df = df.drop(columns=['channel_sales_sddiedcslfslkckwlfkdpoeeailfpeds', 'channel_sales_epumfxlbckeskwekxbiuasklxalciiuu','channel_sales_fixdbufsefwooaasfcxdxadsiekoceaa',
                     'origin_up_MISSING', 'origin_up_usapbepcfoloekilkwsdiboslwaxobdp', 'origin_up_ewxeelcelemmiwuafmddpobolfuxioce'])
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>forecast_cons_12m</th>
      <th>forecast_cons_year</th>
      <th>forecast_discount_energy</th>
      <th>forecast_meter_rent_12m</th>
      <th>forecast_price_energy_off_peak</th>
      <th>forecast_price_energy_peak</th>
      <th>...</th>
      <th>offpeak_diff_dec_january_energy</th>
      <th>offpeak_diff_dec_january_power</th>
      <th>channel_sales_MISSING</th>
      <th>channel_sales_ewpakwlliwisiwduibdlfmalxowmwpci</th>
      <th>channel_sales_foosdfpfkusacimwkcsosbicdxkicaua</th>
      <th>channel_sales_lmkebamcaaclubfxadlmueccxoimlema</th>
      <th>channel_sales_usilxuppasemubllopkaafesmlibmsdf</th>
      <th>origin_up_kamkkxfxxuwbdslkwifmmcsiusiuosws</th>
      <th>origin_up_ldkssxwpmemidmecebumciepifcamkci</th>
      <th>origin_up_lxidpiddsbxsbosboudacockeimpuepw</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>0.00</td>
      <td>0</td>
      <td>0.0</td>
      <td>1.78</td>
      <td>0.114481</td>
      <td>0.098142</td>
      <td>...</td>
      <td>0.020057</td>
      <td>3.700961</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>189.95</td>
      <td>0</td>
      <td>0.0</td>
      <td>16.27</td>
      <td>0.145711</td>
      <td>0.000000</td>
      <td>...</td>
      <td>-0.003767</td>
      <td>0.177779</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>47.96</td>
      <td>0</td>
      <td>0.0</td>
      <td>38.72</td>
      <td>0.165794</td>
      <td>0.087899</td>
      <td>...</td>
      <td>-0.004670</td>
      <td>0.177779</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bba03439a292a1e166f80264c16191cb</td>
      <td>1584</td>
      <td>0</td>
      <td>0</td>
      <td>240.04</td>
      <td>0</td>
      <td>0.0</td>
      <td>19.83</td>
      <td>0.146694</td>
      <td>0.000000</td>
      <td>...</td>
      <td>-0.004547</td>
      <td>0.177779</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>149d57cf92fc41cf94415803a877cb4b</td>
      <td>4425</td>
      <td>0</td>
      <td>526</td>
      <td>445.75</td>
      <td>526</td>
      <td>0.0</td>
      <td>131.73</td>
      <td>0.116900</td>
      <td>0.100015</td>
      <td>...</td>
      <td>-0.006192</td>
      <td>0.162916</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 48 columns</p>
</div>




```python
Transform Numerical Data
```


      Cell In[76], line 1
        Transform Numerical Data
                  ^
    SyntaxError: invalid syntax
    



```python
From the previous EDA we can see that some features are highly skewed, we need to transform the distribution to normal-like distribution. We will use log transfomation via Numpy by calling the log() function on the desired column. First, we will check skewed features, so that we can compare before and after transformation
```


      Cell In[77], line 1
        From the previous EDA we can see that some features are highly skewed, we need to transform the distribution to normal-like distribution. We will use log transfomation via Numpy by calling the log() function on the desired column. First, we will check skewed features, so that we can compare before and after transformation
             ^
    SyntaxError: invalid syntax
    



```python
numeric_features = df[[
    'cons_12m', 
    'cons_gas_12m', 
    'cons_last_month',
    'forecast_cons_12m', 
    'forecast_cons_year', 
    'forecast_discount_energy',
    'forecast_meter_rent_12m', 
    'forecast_price_energy_off_peak',
    'forecast_price_energy_peak', 
    'forecast_price_pow_off_peak'
]]
numeric_features.describe().T

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>cons_12m</th>
      <td>14606.0</td>
      <td>159220.286252</td>
      <td>573465.264198</td>
      <td>0.0</td>
      <td>5674.750000</td>
      <td>14115.500000</td>
      <td>40763.750000</td>
      <td>6.207104e+06</td>
    </tr>
    <tr>
      <th>cons_gas_12m</th>
      <td>14606.0</td>
      <td>28092.375325</td>
      <td>162973.059057</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4.154590e+06</td>
    </tr>
    <tr>
      <th>cons_last_month</th>
      <td>14606.0</td>
      <td>16090.269752</td>
      <td>64364.196422</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>792.500000</td>
      <td>3383.000000</td>
      <td>7.712030e+05</td>
    </tr>
    <tr>
      <th>forecast_cons_12m</th>
      <td>14606.0</td>
      <td>1868.614880</td>
      <td>2387.571531</td>
      <td>0.0</td>
      <td>494.995000</td>
      <td>1112.875000</td>
      <td>2401.790000</td>
      <td>8.290283e+04</td>
    </tr>
    <tr>
      <th>forecast_cons_year</th>
      <td>14606.0</td>
      <td>1399.762906</td>
      <td>3247.786255</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>314.000000</td>
      <td>1745.750000</td>
      <td>1.753750e+05</td>
    </tr>
    <tr>
      <th>forecast_discount_energy</th>
      <td>14606.0</td>
      <td>0.966726</td>
      <td>5.108289</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.000000e+01</td>
    </tr>
    <tr>
      <th>forecast_meter_rent_12m</th>
      <td>14606.0</td>
      <td>63.086871</td>
      <td>66.165783</td>
      <td>0.0</td>
      <td>16.180000</td>
      <td>18.795000</td>
      <td>131.030000</td>
      <td>5.993100e+02</td>
    </tr>
    <tr>
      <th>forecast_price_energy_off_peak</th>
      <td>14606.0</td>
      <td>0.137283</td>
      <td>0.024623</td>
      <td>0.0</td>
      <td>0.116340</td>
      <td>0.143166</td>
      <td>0.146348</td>
      <td>2.739630e-01</td>
    </tr>
    <tr>
      <th>forecast_price_energy_peak</th>
      <td>14606.0</td>
      <td>0.050491</td>
      <td>0.049037</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.084138</td>
      <td>0.098837</td>
      <td>1.959750e-01</td>
    </tr>
    <tr>
      <th>forecast_price_pow_off_peak</th>
      <td>14606.0</td>
      <td>43.130056</td>
      <td>4.485988</td>
      <td>0.0</td>
      <td>40.606701</td>
      <td>44.311378</td>
      <td>44.311378</td>
      <td>5.926638e+01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot a histogram for each numeric feature
for col in numeric_features:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    feature = df[col]
    sns.distplot(feature, ax = ax, color="purple")
    ax.set_title(col)
plt.show()
```


    
![png](output_33_0.png)
    



    
![png](output_33_1.png)
    



    
![png](output_33_2.png)
    



    
![png](output_33_3.png)
    



    
![png](output_33_4.png)
    



    
![png](output_33_5.png)
    



    
![png](output_33_6.png)
    



    
![png](output_33_7.png)
    



    
![png](output_33_8.png)
    



    
![png](output_33_9.png)
    



```python
We can see that the standard deviation for most of these features is quite high. Note that we cannot apply log to a value of 0, so we will add a constant of 1 to all the values.
```


      Cell In[80], line 1
        We can see that the standard deviation for most of these features is quite high. Note that we cannot apply log to a value of 0, so we will add a constant of 1 to all the values.
           ^
    SyntaxError: invalid syntax
    



```python
for i in numeric_features:
    df[i]=df[i].apply(lambda x:np.log(1+x))
```


```python
Let's quickly check the distributions after log transformation.
```


      Cell In[81], line 1
        Let's quickly check the distributions after log transformation.
           ^
    SyntaxError: unterminated string literal (detected at line 1)
    



```python
# Plot a histogram for each numeric feature
for col in numeric_features:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    feature = df[col]
    sns.distplot(feature, ax = ax, color="blue")
    ax.set_title(col)
plt.show()

```


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    Cell In[82], line 8
          6     sns.distplot(feature, ax = ax, color="blue")
          7     ax.set_title(col)
    ----> 8 plt.show()
    

    File ~\anaconda3\Lib\site-packages\matplotlib\pyplot.py:446, in show(*args, **kwargs)
        402 """
        403 Display all open figures.
        404 
       (...)
        443 explicitly there.
        444 """
        445 _warn_if_gui_out_of_main_thread()
    --> 446 return _get_backend_mod().show(*args, **kwargs)
    

    File ~\anaconda3\Lib\site-packages\matplotlib_inline\backend_inline.py:90, in show(close, block)
         88 try:
         89     for figure_manager in Gcf.get_all_fig_managers():
    ---> 90         display(
         91             figure_manager.canvas.figure,
         92             metadata=_fetch_figure_metadata(figure_manager.canvas.figure)
         93         )
         94 finally:
         95     show._to_draw = []
    

    File ~\anaconda3\Lib\site-packages\IPython\core\display_functions.py:298, in display(include, exclude, metadata, transient, display_id, raw, clear, *objs, **kwargs)
        296     publish_display_data(data=obj, metadata=metadata, **kwargs)
        297 else:
    --> 298     format_dict, md_dict = format(obj, include=include, exclude=exclude)
        299     if not format_dict:
        300         # nothing to display (e.g. _ipython_display_ took over)
        301         continue
    

    File ~\anaconda3\Lib\site-packages\IPython\core\formatters.py:179, in DisplayFormatter.format(self, obj, include, exclude)
        177 md = None
        178 try:
    --> 179     data = formatter(obj)
        180 except:
        181     # FIXME: log the exception
        182     raise
    

    File ~\anaconda3\Lib\site-packages\decorator.py:232, in decorate.<locals>.fun(*args, **kw)
        230 if not kwsyntax:
        231     args, kw = fix(args, kw, sig)
    --> 232 return caller(func, *(extras + args), **kw)
    

    File ~\anaconda3\Lib\site-packages\IPython\core\formatters.py:223, in catch_format_error(method, self, *args, **kwargs)
        221 """show traceback on failed format call"""
        222 try:
    --> 223     r = method(self, *args, **kwargs)
        224 except NotImplementedError:
        225     # don't warn on NotImplementedErrors
        226     return self._check_return(None, args[0])
    

    File ~\anaconda3\Lib\site-packages\IPython\core\formatters.py:340, in BaseFormatter.__call__(self, obj)
        338     pass
        339 else:
    --> 340     return printer(obj)
        341 # Finally look for special method names
        342 method = get_real_method(obj, self.print_method)
    

    File ~\anaconda3\Lib\site-packages\IPython\core\pylabtools.py:152, in print_figure(fig, fmt, bbox_inches, base64, **kwargs)
        149     from matplotlib.backend_bases import FigureCanvasBase
        150     FigureCanvasBase(fig)
    --> 152 fig.canvas.print_figure(bytes_io, **kw)
        153 data = bytes_io.getvalue()
        154 if fmt == 'svg':
    

    File ~\anaconda3\Lib\site-packages\matplotlib\backend_bases.py:2342, in FigureCanvasBase.print_figure(self, filename, dpi, facecolor, edgecolor, orientation, format, bbox_inches, pad_inches, bbox_extra_artists, backend, **kwargs)
       2336     renderer = _get_renderer(
       2337         self.figure,
       2338         functools.partial(
       2339             print_method, orientation=orientation)
       2340     )
       2341     with getattr(renderer, "_draw_disabled", nullcontext)():
    -> 2342         self.figure.draw(renderer)
       2344 if bbox_inches:
       2345     if bbox_inches == "tight":
    

    File ~\anaconda3\Lib\site-packages\matplotlib\artist.py:95, in _finalize_rasterization.<locals>.draw_wrapper(artist, renderer, *args, **kwargs)
         93 @wraps(draw)
         94 def draw_wrapper(artist, renderer, *args, **kwargs):
    ---> 95     result = draw(artist, renderer, *args, **kwargs)
         96     if renderer._rasterizing:
         97         renderer.stop_rasterizing()
    

    File ~\anaconda3\Lib\site-packages\matplotlib\artist.py:72, in allow_rasterization.<locals>.draw_wrapper(artist, renderer)
         69     if artist.get_agg_filter() is not None:
         70         renderer.start_filter()
    ---> 72     return draw(artist, renderer)
         73 finally:
         74     if artist.get_agg_filter() is not None:
    

    File ~\anaconda3\Lib\site-packages\matplotlib\figure.py:3175, in Figure.draw(self, renderer)
       3172         # ValueError can occur when resizing a window.
       3174 self.patch.draw(renderer)
    -> 3175 mimage._draw_list_compositing_images(
       3176     renderer, self, artists, self.suppressComposite)
       3178 for sfig in self.subfigs:
       3179     sfig.draw(renderer)
    

    File ~\anaconda3\Lib\site-packages\matplotlib\image.py:131, in _draw_list_compositing_images(renderer, parent, artists, suppress_composite)
        129 if not_composite or not has_images:
        130     for a in artists:
    --> 131         a.draw(renderer)
        132 else:
        133     # Composite any adjacent images together
        134     image_group = []
    

    File ~\anaconda3\Lib\site-packages\matplotlib\artist.py:72, in allow_rasterization.<locals>.draw_wrapper(artist, renderer)
         69     if artist.get_agg_filter() is not None:
         70         renderer.start_filter()
    ---> 72     return draw(artist, renderer)
         73 finally:
         74     if artist.get_agg_filter() is not None:
    

    File ~\anaconda3\Lib\site-packages\matplotlib\axes\_base.py:3064, in _AxesBase.draw(self, renderer)
       3061 if artists_rasterized:
       3062     _draw_rasterized(self.figure, artists_rasterized, renderer)
    -> 3064 mimage._draw_list_compositing_images(
       3065     renderer, self, artists, self.figure.suppressComposite)
       3067 renderer.close_group('axes')
       3068 self.stale = False
    

    File ~\anaconda3\Lib\site-packages\matplotlib\image.py:131, in _draw_list_compositing_images(renderer, parent, artists, suppress_composite)
        129 if not_composite or not has_images:
        130     for a in artists:
    --> 131         a.draw(renderer)
        132 else:
        133     # Composite any adjacent images together
        134     image_group = []
    

    File ~\anaconda3\Lib\site-packages\matplotlib\artist.py:72, in allow_rasterization.<locals>.draw_wrapper(artist, renderer)
         69     if artist.get_agg_filter() is not None:
         70         renderer.start_filter()
    ---> 72     return draw(artist, renderer)
         73 finally:
         74     if artist.get_agg_filter() is not None:
    

    File ~\anaconda3\Lib\site-packages\matplotlib\axis.py:1383, in Axis.draw(self, renderer, *args, **kwargs)
       1380     tick.draw(renderer)
       1382 # Shift label away from axes to avoid overlapping ticklabels.
    -> 1383 self._update_label_position(renderer)
       1384 self.label.draw(renderer)
       1386 self._update_offset_text_position(tlb1, tlb2)
    

    File ~\anaconda3\Lib\site-packages\matplotlib\axis.py:2310, in XAxis._update_label_position(self, renderer)
       2308 try:
       2309     spine = self.axes.spines['bottom']
    -> 2310     spinebbox = spine.get_window_extent()
       2311 except KeyError:
       2312     # use Axes if spine doesn't exist
       2313     spinebbox = self.axes.bbox
    

    File ~\anaconda3\Lib\site-packages\matplotlib\spines.py:165, in Spine.get_window_extent(self, renderer)
        163 if tick is None:
        164     continue
    --> 165 bb0 = bb.frozen()
        166 tickl = tick._size
        167 tickdir = tick._tickdir
    

    File ~\anaconda3\Lib\site-packages\matplotlib\transforms.py:787, in Bbox.frozen(self)
        784 def frozen(self):
        785     # docstring inherited
        786     frozen_bbox = super().frozen()
    --> 787     frozen_bbox._minpos = self.minpos.copy()
        788     return frozen_bbox
    

    KeyboardInterrupt: 



```python
Correlations
Correlation reveals the linear relationships between features. We want features to correlate with churn, as this will indicate that they are good predictors of it. However features that have a very high correlation can sometimes be suspicious. This is because 2 columns that have high correlation indicates that they may share a lot of the same information.

For features to be independent, this means that each feature must have absolutely no dependence on any other feature. If two features are highly correlated and share similar information, we can remove them.
```


```python
numeric_df = df.select_dtypes(include=['number'])
correlation = numeric_df.corr()
print(correlation)
correlation = df.corr()
```


```python
# Plot correlation
plt.figure(figsize=(45, 45))
sns.heatmap(
    correlation, 
    xticklabels=correlation.columns.values,
    yticklabels=correlation.columns.values, 
    annot=True, 
    annot_kws={'size': 12}
)
# Axis ticks size
plt.xticks(fontsize=15)
plt.yticks(fontsize=15)
plt.show()

```


    
![png](output_40_0.png)
    



```python
I will leave it as an exercise for yourself to decide which features to remove based on the correlation results (there are various methods you can use to decide which features to remove).

For now, I will remove two variables which exhibit a high correlation with other independent features.
```


```python
df = df.drop(columns=['num_years_antig', 'forecast_cons_year'])
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>cons_12m</th>
      <th>cons_gas_12m</th>
      <th>cons_last_month</th>
      <th>forecast_cons_12m</th>
      <th>forecast_discount_energy</th>
      <th>forecast_meter_rent_12m</th>
      <th>forecast_price_energy_off_peak</th>
      <th>forecast_price_energy_peak</th>
      <th>forecast_price_pow_off_peak</th>
      <th>...</th>
      <th>offpeak_diff_dec_january_energy</th>
      <th>offpeak_diff_dec_january_power</th>
      <th>channel_sales_MISSING</th>
      <th>channel_sales_ewpakwlliwisiwduibdlfmalxowmwpci</th>
      <th>channel_sales_foosdfpfkusacimwkcsosbicdxkicaua</th>
      <th>channel_sales_lmkebamcaaclubfxadlmueccxoimlema</th>
      <th>channel_sales_usilxuppasemubllopkaafesmlibmsdf</th>
      <th>origin_up_kamkkxfxxuwbdslkwifmmcsiusiuosws</th>
      <th>origin_up_ldkssxwpmemidmecebumciepifcamkci</th>
      <th>origin_up_lxidpiddsbxsbosboudacockeimpuepw</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>24011ae4ebbe3035111d65fa7c15bc57</td>
      <td>0</td>
      <td>54946</td>
      <td>0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>1.78</td>
      <td>0.114481</td>
      <td>0.098142</td>
      <td>40.606701</td>
      <td>...</td>
      <td>0.020057</td>
      <td>3.700961</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d29c2c54acc38ff3c0614d0a653813dd</td>
      <td>4660</td>
      <td>0</td>
      <td>0</td>
      <td>189.95</td>
      <td>0.0</td>
      <td>16.27</td>
      <td>0.145711</td>
      <td>0.000000</td>
      <td>44.311378</td>
      <td>...</td>
      <td>-0.003767</td>
      <td>0.177779</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>764c75f661154dac3a6c254cd082ea7d</td>
      <td>544</td>
      <td>0</td>
      <td>0</td>
      <td>47.96</td>
      <td>0.0</td>
      <td>38.72</td>
      <td>0.165794</td>
      <td>0.087899</td>
      <td>44.311378</td>
      <td>...</td>
      <td>-0.004670</td>
      <td>0.177779</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bba03439a292a1e166f80264c16191cb</td>
      <td>1584</td>
      <td>0</td>
      <td>0</td>
      <td>240.04</td>
      <td>0.0</td>
      <td>19.83</td>
      <td>0.146694</td>
      <td>0.000000</td>
      <td>44.311378</td>
      <td>...</td>
      <td>-0.004547</td>
      <td>0.177779</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>149d57cf92fc41cf94415803a877cb4b</td>
      <td>4425</td>
      <td>0</td>
      <td>526</td>
      <td>445.75</td>
      <td>0.0</td>
      <td>131.73</td>
      <td>0.116900</td>
      <td>0.100015</td>
      <td>40.606701</td>
      <td>...</td>
      <td>-0.006192</td>
      <td>0.162916</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 46 columns</p>
</div>



5. Modelling


```python
We now have a dataset containing features that we have engineered and we are ready to start training a predictive model. Remember, we only need to focus on training a Random Forest classifier.
```


```python
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
```


```python
Data sampling
The first thing we want to do is split our dataset into training and test samples. The reason why we do this, is so that we can simulate a real life situation by generating predictions for our test sample, without showing the predictive model these data points. This gives us the ability to see how well our model is able to generalise to new data, which is critical.

A typical % to dedicate to testing is between 20-30, for this example we will use a 75-25% split between train and test respectively.
```


```python
# Make a copy of our data
train_df = df.copy()

# Separate target variable from independent variables
y = df['churn']
X = df.drop(columns=['id', 'churn'])
print(X.shape)
print(y.shape)
```

    (14606, 44)
    (14606,)
    


```python
(14606, 61)
(14606,)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)
```

    (10954, 44)
    (10954,)
    (3652, 44)
    (3652,)
    


```python
Logistic Regression
```


```python
# Train the model
from sklearn.linear_model import LogisticRegression

# Set regularization rate
reg = 0.01

# train a logistic regression model on the training set
model = LogisticRegression(C=1/reg, solver="liblinear").fit(X_train, y_train)
print (model)
```

    LogisticRegression(C=100.0, solver='liblinear')
    


```python
y_pred = model.predict(X_test)
```


```python
#Let's check the accuracy of the predictions 
from sklearn.metrics import accuracy_score

print('Accuracy: ', accuracy_score(y_test, y_pred))
```

    Accuracy:  0.8932092004381161
    


```python
#create confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred) 
sns.heatmap(cm, square=True, annot=True, cbar=False,  cmap="YlGnBu" ,fmt='g')
plt.xlabel('Predicted')
plt.ylabel('Actual')
```




    Text(113.9222222222222, 0.5, 'Actual')




    
![png](output_53_1.png)
    



```python
from sklearn import metrics
tn, fp, fn, tp = metrics.confusion_matrix(y_test, y_pred).ravel()
print(f"True positives: {tp}")
print(f"False positives: {fp}")
print(f"True negatives: {tn}")
print(f"False negatives: {fn}\n")

```

    True positives: 2
    False positives: 26
    True negatives: 3260
    False negatives: 364
    
    


```python
from sklearn. metrics import classification_report
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.90      0.99      0.94      3286
               1       0.07      0.01      0.01       366
    
        accuracy                           0.89      3652
       macro avg       0.49      0.50      0.48      3652
    weighted avg       0.82      0.89      0.85      3652
    
    


```python
# retrieve the precision_score and recall_score metrics
from sklearn.metrics import precision_score, recall_score

print("Overall Precision:",precision_score(y_test, y_pred))
print("Overall Recall:",recall_score(y_test, y_pred))
```

    Overall Precision: 0.07142857142857142
    Overall Recall: 0.00546448087431694
    


```python
Until now, we've considered the predictions from the model as being either 1 or 0 class labels. Actually, things are a little more complex than that. Statistical machine learning algorithms, like logistic regression, are based on probability; so what actually gets predicted by a binary classifier is the probability that the label is true (P(y)) and the probability that the label is false (1 - P(y)). A threshold value of 0.5 is used to decide whether the predicted label is a 1 (P(y) > 0.5) or a 0 (P(y) <= 0.5). You can use the predict_proba method to see the probability pairs for each case:
```


```python
y_scores = model.predict_proba(X_test)
print(y_scores[:10])
```

    [[0.90732119 0.09267881]
     [0.91085599 0.08914401]
     [0.9211419  0.0788581 ]
     [0.89205192 0.10794808]
     [0.88069047 0.11930953]
     [0.92005379 0.07994621]
     [0.91608496 0.08391504]
     [0.9114448  0.0885552 ]
     [0.99195857 0.00804143]
     [0.95761244 0.04238756]]
    


```python
The decision to score a prediction as a 1 or a 0 depends on the threshold to which the predicted probabilities are compared. If we were to change the threshold, it would affect the predictions; and therefore change the metrics in the confusion matrix. A common way to evaluate a classifier is to examine the true positive rate (which is another name for recall) and the false positive rate for a range of possible thresholds. These rates are then plotted against all possible thresholds to form a chart known as a received operator characteristic (ROC) chart, like this:
```


```python
from sklearn.metrics import roc_curve
# calculate ROC curve
fpr, tpr, thresholds = roc_curve(y_test, y_scores[:,1])

# plot ROC curve
fig = plt.figure(figsize=(6, 6))
# Plot the diagonal 50% line
plt.plot([0, 1], [0, 1], 'k--')
# Plot the FPR and TPR achieved by our model
plt.plot(fpr, tpr)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.show()
```


    
![png](output_60_0.png)
    



```python
The ROC chart shows the curve of the true and false positive rates for different threshold values between 0 and 1. A perfect classifier would have a curve that goes straight up the left side and straight across the top. The diagonal line across the chart represents the probability of predicting correctly with a 50/50 random prediction; so you obviously want the curve to be higher than that (or your model is no better than simply guessing!).

The area under the curve (AUC) is a value between 0 and 1 that quantifies the overall performance of the model. The closer to 1 this value is, the better the model. Once again, scikit-Learn includes a function to calculate this metric.
```


```python
from sklearn.metrics import roc_auc_score

auc = roc_auc_score(y_test,y_scores[:,1])
print('AUC: ' + str(auc))
```

    AUC: 0.5809927195686951
    


```python
1.Looking at the true negatives, we have 3981 out of 3989. This means that out of all the negative cases (churn = 0), we predicted 3981 as negative (hence the name True negative). This is great!

2.Looking at the false negatives, this is where we have predicted a client to not churn (churn = 0) when in fact they did churn (churn = 1). This number is too high at 390, but we want to get the false negatives to as close to 0 as we can.

3.Looking at false positives, this is where we have predicted a client to churn when they actually didnt churn. For this value we can see there are 8, quite good.

4.With the true positives, we can see that in total we have 393 clients that churned in the test dataset. However, we are only able to correctly identify 3 of those 393, which is very poor.

5.Looking at the accuracy score, this is very misleading! Hence the use of precision and recall is important. The accuracy score is high, but it does not tell us the whole story.

6.Looking at the precision score and recall score, this shows us a score of 0.27 and 0.02 which are very bad. This is not a good model.
```


```python
Random Forest
```


```python
from sklearn.ensemble import RandomForestClassifier

model_RF = RandomForestClassifier(n_estimators = 1000).fit(X_train, (y_train))
print (model_RF)
```

    RandomForestClassifier(n_estimators=1000)
    


```python
from sklearn.ensemble import RandomForestClassifier

model_RF = RandomForestClassifier(n_estimators = 1000).fit(X_train, (y_train))
print (model_RF)
RandomForestClassifier(n_estimators=1000)
y_pred_RF = model_RF.predict(X_test)
y_scores_RF = model_RF.predict_proba(X_test)

tn, fp, fn, tp = metrics.confusion_matrix(y_test, y_pred_RF).ravel()
print(f"True positives: {tp}")
print(f"False positives: {fp}")
print(f"True negatives: {tn}")
print(f"False negatives: {fn}\n")

print(classification_report(y_test, y_pred_RF))

print('Accuracy:', accuracy_score(y_test, y_pred_RF))
print("Overall Precision:",precision_score(y_test, y_pred_RF))
print("Overall Recall:",recall_score(y_test, y_pred_RF))
auc = roc_auc_score(y_test,y_scores_RF[:,1])
print('\nAUC: ' + str(auc))

# calculate ROC curve
fpr, tpr, thresholds = roc_curve(y_test, y_scores_RF[:,1])

# plot ROC curve
fig = plt.figure(figsize=(6, 6))
# Plot the diagonal 50% line
plt.plot([0, 1], [0, 1], 'k--')
# Plot the FPR and TPR achieved by our model
plt.plot(fpr, tpr)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.show()
```

    RandomForestClassifier(n_estimators=1000)
    True positives: 18
    False positives: 2
    True negatives: 3284
    False negatives: 348
    
                  precision    recall  f1-score   support
    
               0       0.90      1.00      0.95      3286
               1       0.90      0.05      0.09       366
    
        accuracy                           0.90      3652
       macro avg       0.90      0.52      0.52      3652
    weighted avg       0.90      0.90      0.86      3652
    
    Accuracy: 0.9041621029572837
    Overall Precision: 0.9
    Overall Recall: 0.04918032786885246
    
    AUC: 0.6646827574508845
    


    
![png](output_66_1.png)
    



```python
1.Looking at the true negatives, we have 3984 out of 3989. This is great!

2.Looking at the false negatives, 371 is too high but better than Logistic Model.

3.Looking at false positives, we can see there are only , quite good.

4.With the true positives, we correctly identify 22 of those 393, which is very poor.

5.Looking at the accuracy score, this is very misleading, looking at the precision score and recall score, this shows us a score of 0.81 which is not bad, but could be improved. However, the recall shows us that the classifier has a very poor ability to identify positive samples. This would be the main concern for improving this model!

6.The AUC is better a little bit comparing with Logistic Regression.
```


```python
Model Understanding
```


```python
Feature importances indicate the importance of a feature within the predictive model.
```


```python
feature_importances = pd.DataFrame({
    'features': X_train.columns,
    'importance': model_RF.feature_importances_
}).sort_values(by='importance', ascending=True).reset_index()
```


```python
plt.figure(figsize=(15, 25))
plt.title('Feature Importances')
plt.barh(range(len(feature_importances)), feature_importances['importance'], color='purple', align='center')
plt.yticks(range(len(feature_importances)), feature_importances['features'])
plt.xlabel('Importance')
plt.show()
```


    
![png](output_71_0.png)
    



```python
From this chart, we can observe the following points:

1.Consumption over 12 months and forecast meter rent 12 month are a top driver for churn in this model
2.Net margin also plays an important role in the predictive model.
3.Our price sensitivity features are scattered around but are not the main driver for a customer churning
```
